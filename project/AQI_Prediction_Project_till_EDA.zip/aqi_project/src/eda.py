"""Exploratory Data Analysis (slide 6): histogram, bar, box, scatter, heatmap, count plot."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns, pandas as pd
from .config import FEATURES, TARGET, FIG_DIR, DATA_PATH, REPORT_PATH
from .data_prep import load_data, clean, aqi_category

def run_eda(df, out=FIG_DIR):
    out.mkdir(parents=True, exist_ok=True)
    cols = FEATURES + [TARGET]
    # 1 Histograms
    ax = df[cols].hist(bins=30, figsize=(13, 9), color="#3b7ddd", edgecolor="white")
    plt.suptitle("Feature & target distributions"); plt.tight_layout()
    plt.savefig(out / "01_histograms.png", dpi=130); plt.close()
    # 2 Bar chart - mean pollutant level
    pol = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3"]
    plt.figure(figsize=(7, 4)); df[pol].mean().plot.bar(color="#e07b39")
    plt.ylabel("Mean concentration"); plt.title("Average pollutant levels"); plt.tight_layout()
    plt.savefig(out / "02_bar_mean_pollutants.png", dpi=130); plt.close()
    # 3 Box plots
    plt.figure(figsize=(13, 5)); sns.boxplot(data=(df[cols]-df[cols].mean())/df[cols].std(), color="#7fb77e")
    plt.xticks(rotation=30); plt.title("Box plots (z-scored so scales are comparable)"); plt.tight_layout()
    plt.savefig(out / "03_boxplots.png", dpi=130); plt.close()
    # 4 Scatter PM2.5 vs AQI
    plt.figure(figsize=(6, 4.5)); sns.scatterplot(x="PM2.5", y=TARGET, data=df, s=10, alpha=.4)
    plt.title("PM2.5 vs AQI"); plt.tight_layout(); plt.savefig(out / "04_scatter_pm25_aqi.png", dpi=130); plt.close()
    # 5 Correlation heatmap
    plt.figure(figsize=(9, 7)); sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation heatmap (note PM2.5 / PM10 collinearity)"); plt.tight_layout()
    plt.savefig(out / "05_correlation_heatmap.png", dpi=130); plt.close()
    # 6 Count plot - AQI category frequency (the only categorical view available)
    cats = df[TARGET].map(aqi_category)
    order = ["Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe"]
    plt.figure(figsize=(7, 4)); sns.countplot(x=cats, order=[o for o in order if o in set(cats)], color="#8e6bbf")
    plt.title("Observations per AQI category"); plt.tight_layout()
    plt.savefig(out / "06_countplot_aqi_category.png", dpi=130); plt.close()
    return sorted(p.name for p in out.glob("0[1-6]_*.png"))

if __name__ == "__main__":
    import json
    raw = load_data(DATA_PATH)
    df, report = clean(raw)
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    print("Figures:", run_eda(df))
