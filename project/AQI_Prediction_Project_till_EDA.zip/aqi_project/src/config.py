"""Central configuration (M1: one place where the lifecycle's contracts live)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "air_quality.csv"        # <- put the Kaggle CSV here
FIG_DIR = ROOT / "reports" / "figures"
REPORT_PATH = ROOT / "reports" / "cleaning_report.json"

FEATURES = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3",
            "Temperature", "Humidity", "WindSpeed"]
TARGET = "AQI"

# Kaggle files name columns differently; map the common variants to ours.
COLUMN_ALIASES = {
    "pm2.5": "PM2.5", "pm2_5": "PM2.5", "pm25": "PM2.5", "PM2_5": "PM2.5",
    "pm10": "PM10", "no2": "NO2", "NO₂": "NO2", "so2": "SO2", "SO₂": "SO2",
    "co": "CO", "o3": "O3", "O₃": "O3",
    "temp": "Temperature", "temperature": "Temperature", "TEMP": "Temperature",
    "humidity": "Humidity", "hum": "Humidity",
    "wind speed": "WindSpeed", "wind_speed": "WindSpeed", "Wind Speed": "WindSpeed",
    "windspeed": "WindSpeed", "wind": "WindSpeed",
    "aqi": TARGET, "AQI_Value": TARGET,
}
# Columns that carry no predictive information (slide 7: "record IDs / metadata")
DROP_COLUMNS = ["id", "ID", "index", "Unnamed: 0", "date", "Date", "datetime",
                "city", "City", "station", "Station", "AQI_Bucket"]

RANDOM_STATE = 42          # used by the synthetic-data generator

# Physical sanity ranges used to remove "incorrect data" (slide 5)
VALID_RANGES = {
    "PM2.5": (0, 1000), "PM10": (0, 1500), "NO2": (0, 500), "SO2": (0, 500),
    "CO": (0, 100), "O3": (0, 600), "Temperature": (-50, 60),
    "Humidity": (0, 100), "WindSpeed": (0, 100), TARGET: (0, 500),
}

# CPCB AQI categories
AQI_BANDS = [(50, "Good"), (100, "Satisfactory"), (200, "Moderate"),
             (300, "Poor"), (400, "Very Poor"), (float("inf"), "Severe")]
