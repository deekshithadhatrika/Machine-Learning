"""Creates a realistic stand-in dataset so the project runs without Kaggle.
Replace data/air_quality.csv with the real Kaggle file for the final submission."""
import numpy as np, pandas as pd
from .config import DATA_PATH, RANDOM_STATE

def make(n=5000, seed=RANDOM_STATE):
    r = np.random.default_rng(seed)
    pm25 = r.lognormal(3.7, 0.6, n)
    pm10 = pm25 * r.uniform(1.4, 2.2, n) + r.normal(0, 8, n)      # correlated -> multicollinearity
    no2 = 0.25 * pm25 + r.gamma(4, 6, n)
    so2 = r.gamma(2.5, 6, n) + 0.05 * pm25
    co = 0.4 + 0.012 * pm25 + r.gamma(2, 0.4, n)
    temp = r.normal(27, 7, n)
    hum = np.clip(r.normal(60, 18, n), 5, 100)
    wind = r.gamma(2.5, 1.6, n)
    o3 = np.clip(20 + 1.2 * temp - 0.2 * hum + r.normal(0, 10, n), 1, None)
    aqi = (0.9 * pm25 + 0.25 * pm10 + 0.3 * no2 + 0.15 * so2 + 6 * co + 0.2 * o3
           - 2.0 * wind + r.normal(0, 8, n))
    aqi = np.clip(aqi, 10, 500)
    df = pd.DataFrame({"PM2.5": pm25, "PM10": pm10, "NO2": no2, "SO2": so2, "CO": co,
                       "O3": o3, "Temperature": temp, "Humidity": hum,
                       "WindSpeed": wind, "AQI": aqi}).round(2)
    # realistic mess: missing values, duplicates, a few invalid rows
    for c in ["PM2.5", "PM10", "NO2", "CO", "O3", "Humidity"]:
        df.loc[r.random(n) < 0.03, c] = np.nan
    df = pd.concat([df, df.sample(40, random_state=seed)], ignore_index=True)
    df.loc[r.choice(len(df), 8, replace=False), "Humidity"] = 150    # invalid
    return df

if __name__ == "__main__":
    DATA_PATH.parent.mkdir(exist_ok=True)
    d = make(); d.to_csv(DATA_PATH, index=False)
    print(f"Wrote {DATA_PATH}  shape={d.shape}")
