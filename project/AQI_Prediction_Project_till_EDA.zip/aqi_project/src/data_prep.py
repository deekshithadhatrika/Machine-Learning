"""Data ingestion + cleaning (M1 stage: raw data -> cleaned dataset)."""
import numpy as np, pandas as pd
from .config import (AQI_BANDS, COLUMN_ALIASES, DROP_COLUMNS, FEATURES, TARGET, VALID_RANGES)

def aqi_category(v):
    """CPCB category for an AQI value."""
    for ceil, name in AQI_BANDS:
        if v <= ceil:
            return name

def load_data(path):
    df = pd.read_csv(path)
    df = df.rename(columns={c: COLUMN_ALIASES.get(c, COLUMN_ALIASES.get(str(c).strip().lower(), c))
                            for c in df.columns})
    df = df.drop(columns=[c for c in DROP_COLUMNS if c in df.columns])
    missing = [c for c in FEATURES + [TARGET] if c not in df.columns]
    if missing:
        raise ValueError(f"Columns not found after renaming: {missing}. "
                         f"Edit COLUMN_ALIASES in src/config.py. Found: {list(df.columns)}")
    return df[FEATURES + [TARGET]]

def clean(df):
    """Returns (clean_df, report). Missing feature values are only counted and reported here (not
    imputed): imputation is a modelling-stage decision and is out of scope up to EDA."""
    rep = {"rows_raw": len(df)}
    df = df.apply(pd.to_numeric, errors="coerce")
    rep["duplicates_removed"] = int(df.duplicated().sum())
    df = df.drop_duplicates()
    bad = pd.Series(False, index=df.index)
    for c, (lo, hi) in VALID_RANGES.items():
        bad |= (df[c] < lo) | (df[c] > hi)          # NaN comparisons are False -> kept
    rep["invalid_rows_removed"] = int(bad.sum())
    df = df[~bad]
    rep["rows_missing_target_removed"] = int(df[TARGET].isna().sum())
    df = df.dropna(subset=[TARGET])
    rep["missing_per_feature"] = {k: int(v) for k, v in df[FEATURES].isna().sum().items()}
    q1, q3 = df.quantile(.25), df.quantile(.75); iqr = q3 - q1
    rep["iqr_outliers_per_column"] = {c: int(((df[c] < q1[c] - 1.5*iqr[c]) | (df[c] > q3[c] + 1.5*iqr[c])).sum())
                                      for c in df.columns}
    rep["rows_clean"] = len(df)
    return df.reset_index(drop=True), rep
