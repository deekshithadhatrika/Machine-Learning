import pytest
from src.config import FEATURES, TARGET
from src.data_prep import clean, aqi_category
from src.make_synthetic_data import make
from src.eda import run_eda

def test_clean_removes_duplicates_and_invalid():
    df, rep = clean(make(500))
    assert rep["duplicates_removed"] > 0 and df["Humidity"].max() <= 100 and not df.duplicated().any()

def test_clean_keeps_missing_features_but_drops_missing_target():
    df, rep = clean(make(500))
    assert df[TARGET].notna().all()
    assert set(rep["missing_per_feature"]) == set(FEATURES)

def test_category_bands():
    assert [aqi_category(v) for v in (30, 80, 150, 250, 350, 450)] == \
           ["Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe"]

def test_eda_writes_six_figures(tmp_path):
    df, _ = clean(make(500))
    assert len(run_eda(df, out=tmp_path)) == 6
