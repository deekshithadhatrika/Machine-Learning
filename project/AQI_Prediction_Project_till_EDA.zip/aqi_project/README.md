# Air Quality Index Prediction – up to EDA
Machine Learning (25SC2107E) · Sec 09 · Team 39 · 2520030216 – Dhatrika Deekshitha

This version of the project covers **problem definition → dataset collection → data understanding → preprocessing → exploratory data analysis** (PPT slides 2–6). Feature selection, train–test split, model building, evaluation, the API and monitoring have been removed.

## Quick start
```bash
pip install -r requirements.txt
# Put the Kaggle CSV at data/air_quality.csv (column names are auto-mapped; see COLUMN_ALIASES in src/config.py)
# No dataset yet?  python -m src.make_synthetic_data   <- stand-in data, NOT for final results
python -m src.eda                      # cleans data, writes reports/cleaning_report.json + six EDA figures
pytest tests                           # 4 tests
jupyter notebook notebooks/AQI_Prediction.ipynb
```

## Layout
| Path | Purpose |
|---|---|
| `src/config.py` | features, target, paths, valid ranges, column aliases, AQI bands |
| `src/data_prep.py` | load, rename, drop ID columns, duplicates, invalid values, outlier report, `aqi_category` |
| `src/eda.py` | the six EDA plots from slide 6 (run as a script to also write the cleaning report) |
| `src/make_synthetic_data.py` | stand-in dataset generator |
| `notebooks/AQI_Prediction.ipynb` | step-by-step notebook, slides 2–6 |
| `reports/` | `cleaning_report.json`, `figures/01–06` |
| `tests/` | cleaning, category bands and EDA tests |
| `docs/` | project report (docx) and slide decks |

## PPT slide → code
| Slide | Where |
|---|---|
| 2 Problem definition | notebook §1, README |
| 3 Dataset collection | `load_data`, notebook §2 |
| 4 Data understanding | notebook §3 (`info`, nulls, duplicates, unique, `describe`) |
| 5 Preprocessing | `clean()` |
| 6 EDA | `src/eda.py` → `reports/figures/01–06` |
