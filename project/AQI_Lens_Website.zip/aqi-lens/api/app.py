"""AQI Lens local web application API. All data and processing stay on this computer."""
from pathlib import Path
from typing import List, Any
import json, time
import numpy as np
import pandas as pd
import joblib
from fastapi import FastAPI, HTTPException, Body
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, AliasChoices, ConfigDict, ValidationError

ROOT = Path(__file__).resolve().parents[1]
FEATURES = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3", "Temperature", "Humidity", "WindSpeed"]
LABELS = {"PM2.5":"PM2.5", "PM10":"PM10", "NO2":"NO₂", "SO2":"SO₂", "CO":"CO", "O3":"O₃", "Temperature":"Temperature", "Humidity":"Humidity", "WindSpeed":"Wind speed"}
app = FastAPI(title="AQI Lens", version="3.0", description="Local AQI prediction and model monitoring application")
app.mount("/assets", StaticFiles(directory=ROOT / "assets"), name="assets")

class Reading(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    PM2_5: float = Field(ge=0, le=1000, validation_alias=AliasChoices("PM2_5", "PM2.5"))
    PM10: float = Field(ge=0, le=1500)
    NO2: float = Field(ge=0, le=500)
    SO2: float = Field(ge=0, le=500)
    CO: float = Field(ge=0, le=100)
    O3: float = Field(ge=0, le=600)
    Temperature: float = Field(ge=-50, le=60)
    Humidity: float = Field(ge=0, le=100)
    WindSpeed: float = Field(ge=0, le=100)

class Batch(BaseModel):
    readings: List[Reading] = Field(min_length=1, max_length=500)

def category(a):
    if a <= 50: return "Good"
    if a <= 100: return "Satisfactory"
    if a <= 200: return "Moderate"
    if a <= 300: return "Poor"
    if a <= 400: return "Very Poor"
    return "Severe"

def artifact(name): return ROOT / "artifacts" / name
def load_json(path, default=None):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default

def load_model(name="aqi_regressor.joblib"):
    p=artifact(name)
    if not p.exists(): raise HTTPException(503, "Models are not trained yet. Run start_windows.bat or use the Train models button.")
    return joblib.load(p)

def frame(rows):
    vals=[]
    for r in rows:
        d=r.model_dump() if hasattr(r,"model_dump") else r.dict()
        vals.append([d["PM2_5"],d["PM10"],d["NO2"],d["SO2"],d["CO"],d["O3"],d["Temperature"],d["Humidity"],d["WindSpeed"]])
    return pd.DataFrame(vals,columns=FEATURES)

def read_data():
    p=ROOT/"data"/"air_quality.csv"
    if not p.exists(): raise HTTPException(404,"data/air_quality.csv is missing")
    d=pd.read_csv(p)
    for c in FEATURES+["AQI"]:
        if c in d: d[c]=pd.to_numeric(d[c],errors="coerce")
    return d

@app.get("/")
def home(): return FileResponse(ROOT/"index.html")
@app.get("/health")
def health(): return {"status":"ok","model_available":artifact("aqi_regressor.joblib").exists(),"dataset_available":(ROOT/"data"/"air_quality.csv").exists(),"mode":"local"}
@app.get("/api/summary")
def summary():
    d=read_data(); rep=load_json(ROOT/"reports"/"evaluation_report.json",{})
    clean=d.drop_duplicates().dropna(subset=["AQI"])
    return {"raw_rows":int(len(d)),"clean_rows":int(len(clean)),"duplicate_rows":int(d.duplicated().sum()),"missing":{c:int(d[c].isna().sum()) for c in FEATURES},"feature_count":len(FEATURES),"mean_aqi":round(float(clean.AQI.mean()),2),"median_aqi":round(float(clean.AQI.median()),2),"category_counts":clean.AQI.apply(category).value_counts().to_dict(),"model_ready":artifact("aqi_regressor.joblib").exists(),"report_ready":bool(rep),"selected_model":rep.get("selected_regressor","Not trained yet"),"scores":rep.get("regression_models",{}),"dataset_note":"Local project CSV supplied with the project. Treat predictions as educational estimates, not official health advice."}
@app.get("/api/data")
def data():
    d=read_data(); clean=d.drop_duplicates().copy(); clean=clean.dropna(subset=["AQI"])
    cat=clean.AQI.apply(category)
    counts=cat.value_counts().reindex(["Good","Satisfactory","Moderate","Poor","Very Poor","Severe"],fill_value=0).to_dict()
    stats={c:{"mean":round(float(clean[c].mean()),3) if clean[c].notna().any() else None,"median":round(float(clean[c].median()),3) if clean[c].notna().any() else None,"missing":int(d[c].isna().sum()),"min":round(float(clean[c].min()),3) if clean[c].notna().any() else None,"max":round(float(clean[c].max()),3) if clean[c].notna().any() else None} for c in FEATURES+["AQI"]}
    corr=clean[FEATURES+["AQI"]].corr(numeric_only=True).round(3).replace({np.nan:None}).to_dict()
    sample=clean.sample(min(12,len(clean)),random_state=42).replace({np.nan:None}).to_dict(orient="records")
    return {"rows":int(len(d)),"clean_rows":int(len(clean)),"missing":{c:int(d[c].isna().sum()) for c in FEATURES+["AQI"]},"stats":stats,"category_counts":counts,"correlation":corr,"sample":sample}
@app.get("/api/report")
def report():
    r=load_json(ROOT/"reports"/"evaluation_report.json")
    if not r: raise HTTPException(404,"Evaluation report not found. Train models first.")
    return r
@app.post("/api/predict")
def predict(r: Reading):
    model=load_model(); t=time.perf_counter(); x=frame([r]); value=float(np.clip(model.predict(x)[0],0,500)); elapsed=(time.perf_counter()-t)*1000
    return {"predicted_aqi":round(value,2),"category":category(value),"model":"selected Ridge/Lasso pipeline","model_version":"local-v1","latency_ms":round(elapsed,2),"note":"Educational estimate; not an official monitoring station reading."}
def normalize_reading_keys(row: dict) -> dict:
    """Accept common spellings copied from the UI, notebook, or CSV headers."""
    aliases = {
        "PM2.5": "PM2_5", "PM2_5": "PM2_5", "PM25": "PM2_5", "pm2.5": "PM2_5", "pm2_5": "PM2_5",
        "PM10": "PM10", "NO2": "NO2", "NO₂": "NO2", "SO2": "SO2", "SO₂": "SO2",
        "CO": "CO", "O3": "O3", "O₃": "O3", "Temperature": "Temperature", "temperature": "Temperature",
        "Humidity": "Humidity", "humidity": "Humidity", "WindSpeed": "WindSpeed", "Wind Speed": "WindSpeed", "wind_speed": "WindSpeed"
    }
    return {aliases.get(str(k), str(k)): v for k, v in row.items()}

@app.post("/api/predict/batch")
def batch(payload: Any = Body(...)):
    # Accept either a bare JSON array or the UI's {"readings": [...]} format.
    raw_rows = payload.get("readings") if isinstance(payload, dict) else payload
    if not isinstance(raw_rows, list) or not raw_rows:
        raise HTTPException(422, "Batch input must be a non-empty JSON array or an object containing a non-empty 'readings' array.")
    if len(raw_rows) > 500:
        raise HTTPException(422, "Batch prediction supports up to 500 rows per request.")
    try:
        rows = [r if isinstance(r, Reading) else Reading.model_validate(normalize_reading_keys(r)) for r in raw_rows]
    except (ValidationError, AttributeError) as exc:
        if isinstance(exc, ValidationError):
            issues = []
            for err in exc.errors():
                loc = " → ".join(str(part) for part in err.get("loc", []))
                issues.append(f"{loc}: {err.get('msg', 'Invalid value')}")
            raise HTTPException(422, "Batch row validation failed: " + "; ".join(issues))
        raise HTTPException(422, "Each batch row must be a JSON object containing all nine numeric readings.")
    model=load_model(); t=time.perf_counter(); x=frame(rows); values=np.clip(model.predict(x),0,500)
    return {"count":len(values),"latency_ms":round((time.perf_counter()-t)*1000,2),"predictions":[{"predicted_aqi":round(float(v),2),"category":category(float(v))} for v in values]}
@app.get("/api/monitoring")
def monitoring():
    rep=load_json(ROOT/"reports"/"evaluation_report.json",{})
    base=rep.get("monitoring_baseline",{})
    return {"baseline":base,"report_created":rep.get("created_utc"),"model_ready":artifact("aqi_regressor.joblib").exists(),"status":"baseline available" if base else "train models to generate baseline"}
@app.post("/api/train")
def train():
    import subprocess, sys
    script=ROOT/"api"/"ml_pipeline.py"
    try:
        p=subprocess.run([sys.executable,str(script),"--data",str(ROOT/"data"/"air_quality.csv"),"--quick"],cwd=ROOT,capture_output=True,text=True,timeout=600)
    except subprocess.TimeoutExpired: raise HTTPException(504,"Training exceeded 10 minutes. Try running the training command in the terminal.")
    if p.returncode: raise HTTPException(500,"Training failed: "+(p.stderr or p.stdout)[-2500:])
    return {"status":"trained","message":"Training and evaluation completed. Reports and model artifacts were refreshed.","details":load_json(ROOT/"reports"/"evaluation_report.json",{})}
