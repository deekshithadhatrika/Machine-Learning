@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run start_windows.bat first to install dependencies.& pause & exit /b 1)
call .venv\Scripts\activate.bat
python api\ml_pipeline.py --data data\air_quality.csv --quick
if errorlevel 1 (echo Training failed. See the error above.& pause & exit /b 1)
echo Training complete. Refresh the Model Lab page in the website.
pause
