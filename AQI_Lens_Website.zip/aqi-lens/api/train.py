"""Compatibility entry point: trains the production regressor from data/air_quality.csv."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from api.ml_pipeline import main
if __name__ == '__main__':
    # Full M5/M6 pipeline, including model artifacts and evaluation report.
    main()
