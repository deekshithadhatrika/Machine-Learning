"""AQI Lens training/evaluation pipeline for M5 and M6 topics.

Run from project root: python -m api.ml_pipeline --data data/air_quality.csv
Expected columns: AQI plus the nine features listed below.
Outputs go to artifacts/ and reports/. Bayesian search is used when scikit-optimize is installed;
otherwise randomized search is used and the report records the fallback.
"""
from __future__ import annotations
import argparse, json, os, platform, time, warnings
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import sklearn
from sklearn.base import clone
from sklearn.cluster import KMeans
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
    mean_absolute_percentage_error, accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, roc_auc_score, average_precision_score,
    classification_report)
from sklearn.model_selection import (train_test_split, KFold, StratifiedKFold,
    GridSearchCV, RandomizedSearchCV, cross_val_score, learning_curve)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.inspection import permutation_importance
from sklearn.utils import resample
import joblib

FEATURES = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3", "Temperature", "Humidity", "WindSpeed"]
TARGET = "AQI"
ROOT = Path(__file__).resolve().parents[1]


def aqi_category(v):
    if v <= 50: return "Good"
    if v <= 100: return "Satisfactory"
    if v <= 200: return "Moderate"
    if v <= 300: return "Poor"
    if v <= 400: return "Very Poor"
    return "Severe"


def regression_scores(y, pred):
    denom = np.maximum(np.abs(np.asarray(y)), 1.0)  # avoids undefined MAPE at zero
    return {"MAE": float(mean_absolute_error(y, pred)),
            "RMSE": float(np.sqrt(mean_squared_error(y, pred))),
            "MAPE_percent": float(np.mean(np.abs((np.asarray(y)-np.asarray(pred))/denom))*100),
            "R2": float(r2_score(y, pred))}


def paired_bootstrap(y, pred_a, pred_b, n=2000, seed=42):
    """95% percentile CI for MAE(A)-MAE(B), resampling paired test rows."""
    rng = np.random.default_rng(seed); y=np.asarray(y); a=np.asarray(pred_a); b=np.asarray(pred_b)
    diffs=[]
    for _ in range(n):
        ix=rng.integers(0, len(y), len(y))
        diffs.append(mean_absolute_error(y[ix], a[ix])-mean_absolute_error(y[ix], b[ix]))
    return {"metric":"MAE(A)-MAE(B)", "ci95_low":float(np.percentile(diffs,2.5)),
            "ci95_high":float(np.percentile(diffs,97.5)), "bootstrap_samples":n}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data', default='data/air_quality.csv')
    ap.add_argument('--quick', action='store_true', help='smaller searches for a quick demo')
    args=ap.parse_args(); data_path=Path(args.data)
    if not data_path.is_absolute(): data_path=ROOT/data_path
    if not data_path.exists():
        raise SystemExit(f"Dataset not found: {data_path}\nPlace your real air_quality.csv in {ROOT/'data'}; it must contain AQI and these columns: {', '.join(FEATURES)}")
    df=pd.read_csv(data_path).drop_duplicates()
    missing=[c for c in FEATURES+[TARGET] if c not in df.columns]
    if missing: raise SystemExit(f"Missing required CSV columns: {missing}")
    for c in FEATURES+[TARGET]: df[c]=pd.to_numeric(df[c], errors='coerce')
    df=df.replace([np.inf,-np.inf], np.nan).dropna(subset=[TARGET])
    df=df[df[TARGET].between(0,500)]
    if len(df)<30: raise SystemExit('Need at least 30 valid rows to run a meaningful split and cross-validation.')
    X=df[FEATURES].copy(); y=df[TARGET].astype(float).copy()
    # Hold out test set before any model selection; do not tune against it.
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,random_state=42)
    cv=KFold(n_splits=5,shuffle=True,random_state=42)
    base=Pipeline([('imputer',SimpleImputer(strategy='median', add_indicator=True)),
                   ('scale',StandardScaler()),('model',Ridge())])
    grid={'model__alpha':[0.01,0.1,1,10,100,1000]}
    grid_search=GridSearchCV(base,grid,cv=cv,scoring='neg_root_mean_squared_error',n_jobs=-1)
    grid_search.fit(X_train,y_train)
    best=grid_search.best_estimator_
    candidates={'Ridge (grid search)':best}
    # Random search over Lasso; its search remains confined to training rows.
    lasso=Pipeline([('imputer',SimpleImputer(strategy='median', add_indicator=True)),
                    ('scale',StandardScaler()),('model',Lasso(max_iter=20000))])
    random_search=RandomizedSearchCV(lasso,{'model__alpha':np.logspace(-3,2,30)},n_iter=8 if args.quick else 20,
        cv=cv,scoring='neg_root_mean_squared_error',random_state=42,n_jobs=-1)
    random_search.fit(X_train,y_train); candidates['Lasso (random search)']=random_search.best_estimator_
    search_method='RandomizedSearchCV (fallback; install scikit-optimize for BayesianSearchCV)' 
    try:
        from skopt import BayesSearchCV
        from skopt.space import Real
        bayes=BayesSearchCV(clone(base), {'model__alpha':Real(1e-3,1e3,prior='log-uniform')}, n_iter=8 if args.quick else 20,
            cv=cv,scoring='neg_root_mean_squared_error',random_state=42,n_jobs=-1)
        bayes.fit(X_train,y_train); candidates['Ridge (Bayesian search)']=bayes.best_estimator_; search_method='BayesSearchCV'
    except ImportError: pass
    # Nested CV: inner CV chooses alpha, outer folds estimate generalisation on training portion only.
    inner=KFold(n_splits=3,shuffle=True,random_state=11); outer=KFold(n_splits=5,shuffle=True,random_state=12)
    nested=GridSearchCV(clone(base),grid,cv=inner,scoring='neg_root_mean_squared_error',n_jobs=-1)
    nested_rmse=-cross_val_score(nested,X_train,y_train,cv=outer,scoring='neg_root_mean_squared_error',n_jobs=1)
    # Final comparison on the untouched test set, only after all selection is complete.
    scores={}; preds={}
    for name,model in candidates.items():
        p=np.clip(model.predict(X_test),0,500); preds[name]=p; scores[name]=regression_scores(y_test,p)
    chosen_name=min(scores,key=lambda k:scores[k]['RMSE']); chosen=candidates[chosen_name]; chosen_pred=preds[chosen_name]
    # AQI category classifier with stratified split, metrics and probability calibration.
    cats=y.map(aqi_category); Xtr,Xte,ctr,cte=train_test_split(X,cats,test_size=.2,random_state=42,stratify=cats)
    clf=Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler()),
                  ('model',RandomForestClassifier(n_estimators=160, class_weight='balanced',random_state=42,min_samples_leaf=2))])
    clf.fit(Xtr,ctr); class_pred=clf.predict(Xte); probs=clf.predict_proba(Xte); labels=list(clf.named_steps['model'].classes_)
    # Calibrate on training data only using CV; test remains held out.
    calibrated=CalibratedClassifierCV(clone(clf),method='sigmoid',cv=StratifiedKFold(3,shuffle=True,random_state=42))
    try: calibrated.fit(Xtr,ctr); calibrated_probs=calibrated.predict_proba(Xte)
    except ValueError: calibrated=None; calibrated_probs=probs
    cm=confusion_matrix(cte,class_pred,labels=labels).tolist()
    class_metrics={'accuracy':float(accuracy_score(cte,class_pred)),
        'precision_macro':float(precision_score(cte,class_pred,average='macro',zero_division=0)),
        'recall_macro':float(recall_score(cte,class_pred,average='macro',zero_division=0)),
        'f1_macro':float(f1_score(cte,class_pred,average='macro',zero_division=0)),
        'labels':labels,'confusion_matrix':cm,'classification_report':classification_report(cte,class_pred,output_dict=True,zero_division=0)}
    try:
        ybin=label_binarize(cte,classes=labels)
        class_metrics['roc_auc_ovr_macro']=float(roc_auc_score(ybin,probs,multi_class='ovr',average='macro'))
        class_metrics['pr_auc_macro_ovr']=float(average_precision_score(ybin,probs,average='macro'))
    except ValueError: class_metrics['roc_auc_ovr_macro']=None; class_metrics['pr_auc_macro_ovr']=None
    # Reliability diagram bins for top-probability confidence; expected calibration error.
    conf=probs.max(axis=1); correct=(class_pred==np.asarray(cte)); bins=[]
    for lo in np.linspace(0,0.9,10):
        mask=(conf>=lo)&(conf<lo+.1)
        if mask.any(): bins.append({'confidence_mean':float(conf[mask].mean()),'accuracy':float(correct[mask].mean()),'count':int(mask.sum())})
    ece=sum(b['count']/len(conf)*abs(b['confidence_mean']-b['accuracy']) for b in bins)
    class_metrics['reliability_bins']=bins; class_metrics['expected_calibration_error']=float(ece)
    # Unsupervised segment discovery; cluster IDs become an extra feature for a downstream supervised model.
    cluster_pipe=Pipeline([('imputer',SimpleImputer(strategy='median')),('scale',StandardScaler()),('kmeans',KMeans(n_clusters=4,n_init=10,random_state=42))])
    train_cluster=cluster_pipe.fit_predict(X_train); test_cluster=cluster_pipe.predict(X_test)
    Xtr_aug=X_train.copy(); Xte_aug=X_test.copy(); Xtr_aug['cluster_id']=train_cluster; Xte_aug['cluster_id']=test_cluster
    cluster_downstream=Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler()),('model',Ridge(alpha=10))])
    cluster_downstream.fit(Xtr_aug,y_train); cluster_scores=regression_scores(y_test,np.clip(cluster_downstream.predict(Xte_aug),0,500))
    # Training/serving feature range and permutation importance.
    imp=permutation_importance(chosen,X_test,y_test,n_repeats=5 if args.quick else 15,random_state=42,scoring='neg_mean_absolute_error',n_jobs=-1)
    artifacts=ROOT/'artifacts'; reports=ROOT/'reports'; artifacts.mkdir(exist_ok=True); reports.mkdir(exist_ok=True)
    joblib.dump(chosen,artifacts/'aqi_regressor.joblib'); joblib.dump(clf,artifacts/'aqi_category_classifier.joblib')
    if calibrated is not None: joblib.dump(calibrated,artifacts/'aqi_calibrated_classifier.joblib')
    joblib.dump(cluster_pipe,artifacts/'aqi_clusterer.joblib')
    # Learning curve uses training data only. Validation curve is generated across alpha values.
    sizes,tr_scores,va_scores=learning_curve(clone(chosen),X_train,y_train,cv=cv,train_sizes=np.linspace(.2,1,5),
        scoring='neg_root_mean_squared_error',n_jobs=-1)
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'data_file':str(data_path.name),'rows_used':int(len(df)),
      'features':FEATURES,'target':TARGET,'split':{'train_rows':len(X_train),'test_rows':len(X_test),'test_held_out_until_final_comparison':True},
      'regression_models':scores,'selected_regressor':chosen_name,'best_parameters':chosen.get_params().get('model__alpha'),
      'nested_cv_rmse_mean':float(nested_rmse.mean()),'nested_cv_rmse_std':float(nested_rmse.std()),
      'paired_bootstrap_ridge_vs_lasso':paired_bootstrap(y_test, preds['Ridge (grid search)'],preds['Lasso (random search)'],n=300 if args.quick else 2000),
      'classifier':class_metrics,'cluster_feature_downstream_regression_scores':cluster_scores,
      'feature_importance':{f:float(v) for f,v in zip(FEATURES,imp.importances_mean)},
      'learning_curve':{'train_sizes':sizes.tolist(),'train_rmse_mean':(-tr_scores.mean(axis=1)).tolist(),'validation_rmse_mean':(-va_scores.mean(axis=1)).tolist()},
      'search_method':search_method,'versions':{'python':platform.python_version(),'pandas':pd.__version__,'scikit_learn':sklearn.__version__},
      'monitoring_baseline':{f:{'mean':float(X_train[f].mean()),'std':float(X_train[f].std()),'min':float(X_train[f].min()),'max':float(X_train[f].max())} for f in FEATURES}}
    (reports/'evaluation_report.json').write_text(json.dumps(report,indent=2,default=float))
    # Reproducibility metadata and training-serving contract.
    (artifacts/'model_card.json').write_text(json.dumps({'model':chosen_name,'feature_order':FEATURES,'target':TARGET,
      'training_data':data_path.name,'test_metrics':scores[chosen_name],'trained_utc':report['created_utc'],
      'warning':'Use for educational demonstration, not official public-health decisions.'},indent=2))
    print(json.dumps({'status':'success','selected_regressor':chosen_name,'regression_models':scores,
      'classifier_metrics':{k:v for k,v in class_metrics.items() if k not in ('classification_report','reliability_bins','confusion_matrix')},
      'nested_cv_rmse_mean':report['nested_cv_rmse_mean'],'cluster_downstream_scores':cluster_scores,
      'outputs':['artifacts/aqi_regressor.joblib','artifacts/aqi_category_classifier.joblib','artifacts/aqi_clusterer.joblib','reports/evaluation_report.json']},indent=2))

if __name__=='__main__':
    warnings.filterwarnings('ignore',category=UserWarning)
    main()
