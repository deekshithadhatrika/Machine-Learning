# AQI Lens — Local Air Quality Intelligence

A full local website for the project **Air Quality Index Prediction Using Ridge and Lasso Regression**. It runs on your computer and does not fetch data from or link to external websites. The included dataset, trained models, evaluation report and charts are bundled in this project.

## Run on Windows (recommended)
1. Extract the ZIP to a normal folder, for example `Desktop\aqi-lens`.
2. Install Python 3.10 or newer if it is not already installed.
3. Double-click **`start_windows.bat`**. On first launch it creates a virtual environment and installs Python packages. Package installation requires internet access, but the app itself then runs locally.
4. Keep the black terminal window open.
5. Open Microsoft Edge and visit **http://127.0.0.1:8000**. Do not double-click `index.html` for the fully working app: the browser must connect to the local API.
6. To stop the app, click the terminal and press `Ctrl+C`.

## Website features
- Overview dashboard with live local-dataset summary, AQI category distribution and missing-value counts.
- AQI Predictor with nine validated environmental inputs and actual inference through the saved trained pipeline.
- Batch prediction endpoint and interface for up to 500 rows per request.
- Data Explorer with per-feature statistics, missing values, AQI correlations, sample records and CSV sample export.
- Model Lab with measured held-out Ridge/Lasso results, nested cross-validation estimate, classifier metrics/confusion matrix, calibration bins, permutation importance and learning curve.
- Monitoring view with training-data baseline and input-range/standard-deviation drift warnings.
- Project details and clear limitations. All routes and pages are served locally by FastAPI.

## Re-train models
From the website, open **Model Lab → Train / refresh models**. This runs the quick training pipeline on the included CSV and refreshes model artifacts and `reports/evaluation_report.json`. It may take a few minutes. Alternatively, after running `start_windows.bat` once, use `train_models_windows.bat`.

## Manual setup
Open a terminal in this folder and run:
```powershell
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
py -m uvicorn api.app:app --host 127.0.0.1 --port 8000
```
The included trained model artifacts make prediction available immediately after package setup. Retrain with:
```powershell
py api\ml_pipeline.py --data data\air_quality.csv --quick
```
Interactive API documentation is local at **http://127.0.0.1:8000/docs**.

## Project implementation notes
- Main prediction is a regression problem. Ridge and Lasso are tuned on training data and compared on an untouched test split using MAE, RMSE, MAPE and R².
- The pipeline also computes cross-validation/nested-CV estimates, learning curves, paired bootstrap comparisons, feature importance, and a supplementary AQI-category classifier with classification metrics and calibration bins when supported by the data.
- K-means cluster IDs are added as a feature for a separate downstream regression experiment.
- Monitoring is a local baseline/range check, not a live sensor feed or a proof that accuracy has drifted. Batch inference is local and synchronous.
- gRPC, a managed feature store, ONNX conversion, Docker orchestration, MLflow and DVC are not configured as production services in this project; the website does not pretend they are running.
- The supplied CSV is the file included in the submitted project ZIP. Confirm the original data source and representativeness before drawing real-world conclusions. This is an academic prototype, not an official AQI service or medical advice.

## Folder guide
- `index.html`, `assets/`: full website UI and browser interactions
- `api/app.py`: FastAPI endpoints and static website hosting
- `api/ml_pipeline.py`: preprocessing, model search, evaluation and artifact generation
- `data/air_quality.csv`: dataset included with the project
- `artifacts/`: trained regressor, classifier, clusterer and model card
- `reports/evaluation_report.json`: latest model evaluation and monitoring baseline
- `reference/`: supplied notebook, project report and presentation copies
