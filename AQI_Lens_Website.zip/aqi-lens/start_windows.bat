@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo   AQI Lens - Local Air Quality Intelligence
echo ==============================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher 'py' was not found. Install Python 3.10+ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Creating the project environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Could not create virtual environment.& pause & exit /b 1)
)
call .venv\Scripts\activate.bat
echo Installing/checking required packages. First run may take a few minutes...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (echo Package installation failed. Check your internet connection for package installation only.& pause & exit /b 1)
echo Starting local website. Keep this window open.
echo Open http://127.0.0.1:8000 in Microsoft Edge.
python -m uvicorn api.app:app --host 127.0.0.1 --port 8000
pause
