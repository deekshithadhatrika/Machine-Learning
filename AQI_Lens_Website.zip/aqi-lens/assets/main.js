const $=id=>document.getElementById(id),F=DATA.features,L=["PM2.5","PM10","NO₂","SO₂","CO","O₃","Temperature","Humidity","Wind speed"];
const U=["µg/m³","µg/m³","µg/m³","µg/m³","mg/m³","µg/m³","°C","%","m/s"],MED=[40.3,71.7,34,15.4,1.65,40.2,26.6,60,3.4],LO=[10,13,12,3.5,.7,9,11,18,.5],HI=[170,310,80,50,4,72,43,100,12];
const B=[[50,"Good","#3f9b4f","#e3f1e6","#1b2f26"],[100,"Satisfactory","#8bbf3d","#edf4dc","#26301b"],[200,"Moderate","#e0b81f","#faf2cf","#33301a"],[300,"Poor","#ec8a1f","#fbe6cf","#35291a"],[400,"Very Poor","#d8362f","#f8d9d7","#361d1c"],[500,"Severe","#8a1c2b","#eed3d7","#2f1a1f"]];
const band=a=>B.find(x=>a<=x[0])||B[5],pred=v=>Math.max(0,Math.min(500,DATA.intercept+v.reduce((s,x,i)=>s+x*DATA.rawcoef[i],0)));
const dk=()=>matchMedia("(prefers-color-scheme:dark)").matches;
// header + footer
const P=[["index.html","Predict"],["data.html","Data"],["models.html","Models"],["deploy.html","API & monitoring"],["about.html","About"]],cur=location.pathname.split("/").pop()||"index.html";
document.body.insertAdjacentHTML("afterbegin",`<header class="top"><div class="w"><a class="logo" href="index.html">AQI <b>Lens</b></a><nav>${P.map(p=>`<a href="${p[0]}" class="${p[0]==cur?"on":""}">${p[1]}</a>`).join("")}</nav></div></header>`);
document.body.insertAdjacentHTML("beforeend",`<footer><div class="w">AQI Lens · Air Quality Index prediction with Ridge and Lasso regression · Team 39</div></footer>`);
// svg helpers
const svg=(w,h,s,l)=>`<svg viewBox="0 0 ${w} ${h}" width="100%" role="img" aria-label="${l}">${s}</svg>`;
function hbars(el,rows,max,lab){el.innerHTML=svg(440,rows.length*26+6,rows.map((r,i)=>`<text x="0" y="${i*26+17}">${r[0]}</text><rect class="bar" x="100" y="${i*26+5}" width="${Math.abs(r[1])/max*250}" height="16" rx="3" opacity="${r[1]<0?.5:1}"/><text x="${106+Math.abs(r[1])/max*250}" y="${i*26+17}">${r[1]}</text>`).join(""),lab)}
function lines(el,xs,series,xl,yl,lab,ymax){const W=420,H=230,x=i=>55+i*(330/(xs.length-1)),mx=ymax||Math.max(...series.flatMap(s=>s[1])),y=v=>190-v/mx*165;
el.innerHTML=svg(W,H,[0,.5,1].map(g=>`<line x1="55" x2="385" y1="${y(g*mx)}" y2="${y(g*mx)}" stroke="var(--line)"/><text x="6" y="${y(g*mx)+4}">${Math.round(g*mx)}</text>`).join("")+xs.map((a,i)=>`<text x="${x(i)-10}" y="208">${a}</text>`).join("")+series.map(s=>`<polyline fill="none" stroke="${s[2]}" stroke-width="3" points="${s[1].map((v,i)=>x(i)+","+y(Math.min(v,mx))).join(" ")}"/><text x="${x(xs.length-1)-34}" y="${y(Math.min(s[1].at(-1),mx))-8}" style="fill:${s[2]}">${s[0]}</text>`).join("")+`<text x="170" y="226">${xl}</text><text x="6" y="14">${yl}</text>`,lab)}
// predictor
if($("ctls")){const v=[...MED],box=$("ctls");
L.forEach((n,i)=>{const d=document.createElement("div");d.className="ctl";const hi=HI[i]>20;
d.innerHTML=`<label for="s${i}">${n}</label><input type="range" id="s${i}" min="${LO[i]}" max="${HI[i]}" step="${hi?1:.1}" value="${MED[i]}"><output id="o${i}"></output>`;box.appendChild(d);d.querySelector("input").oninput=e=>{v[i]=+e.target.value;upd()}});
$("scale").insertAdjacentHTML("afterbegin",B.map((b,i)=>`<i style="background:${b[2]};flex:${b[0]-(B[i-1]?B[i-1][0]:0)}"></i>`).join(""));
function upd(){const a=pred(v),b=band(a);v.forEach((x,i)=>$("o"+i).textContent=HI[i]>20?Math.round(x):x.toFixed(1));
$("aqi").textContent=Math.round(a);document.documentElement.style.setProperty("--c",b[2]);$("cat").textContent=b[1];$("pin").style.left=`calc(${a/5}% - 2px)`;
document.querySelector(".hero").style.background=dk()?b[4]:b[3];
const c=v.map((x,i)=>[L[i],DATA.rawcoef[i]*(x-MED[i])]).sort((p,q)=>Math.abs(q[1])-Math.abs(p[1]))[0];
$("why").textContent=Math.abs(c[1])<.5?"All readings are close to a typical day.":`Biggest push from a typical day: ${c[0]} (${c[1]>0?"+":""}${c[1].toFixed(0)} AQI points).`}
$("reset").onclick=()=>{MED.forEach((m,i)=>{v[i]=m;$("s"+i).value=m});upd()};upd()}
// data page
if($("cats")){const o=["Good","Satisfactory","Moderate","Poor","Very Poor","Severe"];hbars($("cats"),o.map(k=>[k,DATA.counts[k]||0]),2700,"Rows per AQI category")}
if($("miss")){const m={"PM2.5":151,PM10:141,NO2:155,CO:160,O3:162,Humidity:169};hbars($("miss"),Object.entries(m),170,"Missing values per column")}
// models page
if($("alpha")){const A=["0.01","0.1","1","10","100","1000"];lines($("alpha"),A,[["Ridge",[9.08,9.08,9.08,9.08,9.13,10.98],"var(--accent)"],["Lasso",[9.08,9.09,9.32,15.83,48.79,48.79],"var(--r)"]],"alpha (regularization strength)","CV RMSE","Cross-validated RMSE by alpha",50);
hbars($("coefR"),F.map((f,i)=>[L[i],DATA.ridge.coef[i]]),27,"Ridge coefficients");hbars($("coefL"),F.map((f,i)=>[L[i],DATA.lasso.coef[i]]),27,"Lasso coefficients");
lines($("lc"),DATA.lc.n,[["Train",DATA.lc.tr,"var(--accent)"],["Validation",DATA.lc.va,"var(--r)"]],"training rows","RMSE","Learning curve",12);
hbars($("band"),Object.entries(DATA.maeBand),20,"MAE by AQI category");
const s=DATA.sc;$("scat").innerHTML=svg(330,300,`<line x1="30" y1="270" x2="300" y2="20" stroke="var(--line)" stroke-width="2"/>`+s.map(p=>`<circle cx="${30+p[0]/500*270*1.15}" cy="${270-p[1]/500*250*1.15}" r="2.5" fill="var(--accent)" opacity=".45"/>`).join("")+`<text x="110" y="292">actual AQI</text><text x="2" y="14">predicted</text>`,"Actual vs predicted AQI")}
// api + monitoring
if($("req")){const ex={PM2_5:48.5,PM10:71.5,NO2:71.7,SO2:8,CO:1.3,O3:60.2,Temperature:36.4,Humidity:51.4,WindSpeed:2.95};$("req").value=JSON.stringify(ex,null,2);
$("send").onclick=()=>{try{const j=JSON.parse($("req").value),k=["PM2_5","PM10","NO2","SO2","CO","O3","Temperature","Humidity","WindSpeed"],miss=k.filter(x=>typeof j[x]!="number");
if(miss.length){$("res").textContent=JSON.stringify({status:422,error:"Missing or non-numeric fields",fields:miss},null,2);return}
const a=pred(k.map(x=>j[x]));$("res").textContent=JSON.stringify({status:200,predicted_aqi:+a.toFixed(1),category:band(a)[1],model:"ridge",version:"1.0"},null,2)}catch(e){$("res").textContent=JSON.stringify({status:400,error:"Request body is not valid JSON"},null,2)}};$("send").click();
const dr=$("drift"),upd=()=>{const sh=+dr.value;$("dv").textContent=(sh>=0?"+":"")+sh;const [m,sd]=DATA.stats["PM2.5"],z=sh/sd,t=sh*.8;
$("z").textContent=z.toFixed(2);const bad=Math.abs(z)>=.5;$("flag").textContent=bad?"Drift detected: schedule retraining":"Inputs look like training data";$("flag").className="flag "+(bad?"bad":"ok");
$("dm").textContent=`Training mean ${m.toFixed(1)} µg/m³, live mean ${(m+sh).toFixed(1)} µg/m³. Expected prediction error grows once live data leaves the range the model learned from.`};dr.oninput=upd;upd()}
